#define VER_MAJOR 0
#define VER_MINOR 1
#define CHAT_MAGIC 123

